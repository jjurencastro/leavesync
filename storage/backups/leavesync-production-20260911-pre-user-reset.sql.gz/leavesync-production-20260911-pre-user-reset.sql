/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_action` (`action`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(7,1,'login_success','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:06:32'),
(8,NULL,'login_success_google','user',2,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:06:50'),
(9,1,'login_success','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:07:22'),
(10,1,'webauthn_credential_registered','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:07:50'),
(11,1,'webauthn_credential_removed','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:07:55'),
(12,1,'login_failed','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:28:14'),
(13,1,'login_failed','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:28:15'),
(14,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:28:21'),
(15,1,'create_user','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:29:09'),
(16,3,'login_success_google','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:29:32'),
(17,3,'login_success_google','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:29:40'),
(18,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:29:46'),
(19,3,'login_success_google','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:31:50'),
(20,3,'login_success_google','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:32:08'),
(21,3,'login_success_google','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:32:20'),
(22,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:32:50'),
(23,3,'login_success_google','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:34:36'),
(24,3,'password_set','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:34:51'),
(25,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:35:04'),
(26,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:35:16'),
(27,1,'create_user','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:35:58'),
(28,4,'login_success_google','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:36:19'),
(29,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:36:31'),
(30,4,'password_set','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:36:48'),
(31,1,'create_user','user',5,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:37:38'),
(32,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:38:09');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_change_requests`
--

DROP TABLE IF EXISTS `device_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_change_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `fingerprint_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `requested_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resolved_by` (`resolved_by`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `device_change_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `device_change_requests_ibfk_2` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_change_requests`
--

LOCK TABLES `device_change_requests` WRITE;
/*!40000 ALTER TABLE `device_change_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_change_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_fingerprints`
--

DROP TABLE IF EXISTS `device_fingerprints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_fingerprints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `fingerprint_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_trusted` tinyint(1) DEFAULT '0',
  `last_used` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_fingerprint` (`fingerprint_hash`),
  CONSTRAINT `device_fingerprints_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_fingerprints`
--

LOCK TABLES `device_fingerprints` WRITE;
/*!40000 ALTER TABLE `device_fingerprints` DISABLE KEYS */;
INSERT INTO `device_fingerprints` VALUES
(1,1,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"203.177.49.42\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','203.177.49.42','Chrome 153',1,'2026-09-11 04:38:09','2026-09-11 03:06:32','2026-09-11 04:38:09'),
(3,3,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"203.177.49.42\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','203.177.49.42','Chrome 153',1,'2026-09-11 04:35:04','2026-09-11 04:34:51','2026-09-11 04:35:04'),
(4,4,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"203.177.49.42\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','203.177.49.42','Chrome 153',1,'2026-09-11 04:36:48','2026-09-11 04:36:48','2026-09-11 04:36:48');
/*!40000 ALTER TABLE `device_fingerprints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `digital_signatures`
--

DROP TABLE IF EXISTS `digital_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_signatures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_id` int NOT NULL,
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signer_id` int NOT NULL,
  `signature_hash` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `certificate_data` longtext COLLATE utf8mb4_unicode_ci,
  `timestamp` timestamp NOT NULL,
  `is_valid` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_document_id` (`document_id`),
  KEY `idx_document_type` (`document_type`),
  KEY `idx_signer_id` (`signer_id`),
  CONSTRAINT `digital_signatures_ibfk_1` FOREIGN KEY (`signer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `digital_signatures`
--

LOCK TABLES `digital_signatures` WRITE;
/*!40000 ALTER TABLE `digital_signatures` DISABLE KEYS */;
/*!40000 ALTER TABLE `digital_signatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_balances`
--

DROP TABLE IF EXISTS `leave_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_balances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leave_type_id` int NOT NULL,
  `total_days` decimal(6,2) DEFAULT NULL,
  `used_days` decimal(6,2) DEFAULT '0.00',
  `pending_days` decimal(6,2) DEFAULT '0.00',
  `balance` decimal(6,2) DEFAULT NULL,
  `fiscal_year` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_leave_type` (`user_id`,`leave_type_id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_fiscal_year` (`fiscal_year`),
  CONSTRAINT `leave_balances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leave_balances_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_balances`
--

LOCK TABLES `leave_balances` WRITE;
/*!40000 ALTER TABLE `leave_balances` DISABLE KEYS */;
INSERT INTO `leave_balances` VALUES
(7,3,1,7.00,0.00,0.00,7.00,2026,'2026-09-11 04:29:09','2026-09-11 04:29:09'),
(8,3,2,5.00,0.00,0.00,5.00,2026,'2026-09-11 04:29:09','2026-09-11 04:29:09'),
(9,3,3,999.00,0.00,0.00,999.00,2026,'2026-09-11 04:29:09','2026-09-11 04:29:09'),
(10,3,4,105.00,0.00,0.00,105.00,2026,'2026-09-11 04:29:09','2026-09-11 04:29:09'),
(11,3,5,7.00,0.00,0.00,7.00,2026,'2026-09-11 04:29:09','2026-09-11 04:29:09'),
(12,3,6,3.00,0.00,0.00,3.00,2026,'2026-09-11 04:29:09','2026-09-11 04:29:09'),
(13,4,1,7.00,0.00,0.00,7.00,2026,'2026-09-11 04:35:58','2026-09-11 04:35:58'),
(14,4,2,5.00,0.00,0.00,5.00,2026,'2026-09-11 04:35:58','2026-09-11 04:35:58'),
(15,4,3,999.00,0.00,0.00,999.00,2026,'2026-09-11 04:35:58','2026-09-11 04:35:58'),
(16,4,4,105.00,0.00,0.00,105.00,2026,'2026-09-11 04:35:58','2026-09-11 04:35:58'),
(17,4,5,7.00,0.00,0.00,7.00,2026,'2026-09-11 04:35:58','2026-09-11 04:35:58'),
(18,4,6,3.00,0.00,0.00,3.00,2026,'2026-09-11 04:35:58','2026-09-11 04:35:58'),
(19,5,1,7.00,0.00,0.00,7.00,2026,'2026-09-11 04:37:38','2026-09-11 04:37:38'),
(20,5,2,5.00,0.00,0.00,5.00,2026,'2026-09-11 04:37:38','2026-09-11 04:37:38'),
(21,5,3,999.00,0.00,0.00,999.00,2026,'2026-09-11 04:37:38','2026-09-11 04:37:38'),
(22,5,4,105.00,0.00,0.00,105.00,2026,'2026-09-11 04:37:38','2026-09-11 04:37:38'),
(23,5,5,7.00,0.00,0.00,7.00,2026,'2026-09-11 04:37:38','2026-09-11 04:37:38'),
(24,5,6,3.00,0.00,0.00,3.00,2026,'2026-09-11 04:37:38','2026-09-11 04:37:38');
/*!40000 ALTER TABLE `leave_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leave_type_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `number_of_days` decimal(6,2) DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','approved','rejected','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `supervisor_status` enum('pending','approved','rejected','not_required') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `hr_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `manager_id` int DEFAULT NULL,
  `manager_comments` text COLLATE utf8mb4_unicode_ci,
  `hr_id` int DEFAULT NULL,
  `hr_comments` text COLLATE utf8mb4_unicode_ci,
  `digital_signature` text COLLATE utf8mb4_unicode_ci,
  `signature_timestamp` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `hr_id` (`hr_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_manager_id` (`manager_id`),
  KEY `idx_start_date` (`start_date`),
  KEY `idx_end_date` (`end_date`),
  CONSTRAINT `leave_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leave_requests_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`),
  CONSTRAINT `leave_requests_ibfk_3` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leave_requests_ibfk_4` FOREIGN KEY (`hr_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `days_per_year` int NOT NULL,
  `is_paid` tinyint(1) DEFAULT '1',
  `requires_documentation` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES
(1,'Vacation Leave','Paid vacation leave; must be filed at least 3 days before the requested start date',7,1,0,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(2,'Sick Leave','Leave for medical reasons',5,1,0,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(3,'Leave Without Pay','Unpaid leave, only usable once Vacation and Sick leave balances are exhausted',999,0,1,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(4,'Maternity Leave','Leave for maternity (RA 11210); female employees only',105,1,1,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(5,'Paternity Leave','Leave for paternity (RA 8187); male employees only',7,1,1,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(6,'Bereavement Leave','Leave for the death of an immediate family member',3,1,1,'2026-09-11 02:57:21','2026-09-11 02:57:21');
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mfa_secrets`
--

DROP TABLE IF EXISTS `mfa_secrets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfa_secrets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_codes` json DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `mfa_secrets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mfa_secrets`
--

LOCK TABLES `mfa_secrets` WRITE;
/*!40000 ALTER TABLE `mfa_secrets` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfa_secrets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_entity_id` int DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,3,'Account activated','Your password was set and this device was registered as a trusted device.','success','user',3,0,'2026-09-11 04:34:51',NULL),
(2,4,'Account activated','Your password was set and this device was registered as a trusted device.','success','user',4,0,'2026-09-11 04:36:48',NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `device_id` (`device_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_token_hash` (`token_hash`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `device_fingerprints` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
(17,1,'c263feee66cbacff7eac5293e3c5fbfa9b434a295864217e0270709321f87cfe',1,'203.177.49.42','2026-10-11 04:46:22','2026-09-11 04:38:09');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_id_sequence`
--

DROP TABLE IF EXISTS `user_id_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_id_sequence` (
  `id` tinyint NOT NULL,
  `next_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_id_sequence`
--

LOCK TABLES `user_id_sequence` WRITE;
/*!40000 ALTER TABLE `user_id_sequence` DISABLE KEYS */;
INSERT INTO `user_id_sequence` VALUES
(1,6);
/*!40000 ALTER TABLE `user_id_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_id` int DEFAULT NULL,
  `role` enum('employee','manager','hr','admin') COLLATE utf8mb4_unicode_ci DEFAULT 'employee',
  `is_active` tinyint(1) DEFAULT '1',
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_key` longtext COLLATE utf8mb4_unicode_ci,
  `password_set` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_supervisor_id` (`supervisor_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','admin@thelewiscollege.edu.ph','$2y$10$VYHGcBlY1AY9YAnbwcxG9uj5fjLUT9WwOks2TuBj/hxOtS/APudJy','System Administrator','ADMIN',NULL,'male',NULL,'admin',1,NULL,NULL,1,'2026-08-26 03:32:46','2026-08-27 00:45:08'),
(3,'josefjurendelcastro','josefjurendelcastro@thelewiscollege.edu.ph','$2y$10$w.N0kX9ehxWYJY5GjI.eJOHGB4CSkhZjLoYK3SbboxBF91SgMYivi','Josef Jurendel Castro','ADMIN','HR Officer','male',1,'hr',1,NULL,'-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAqEzIPp+gbC1wvFnvaARm\nbTsKxDhX6yzLHHUkk+o8raUHqAtXe6m4sZHY1iCuMeP445/j4eEUaLhSPwcPRalM\nLzl7mwgsVWzfW1ahSkJSCGGxJeA3FpWJLpN/1NFWqvCA7C3zyyiglDCkKq/9oHt5\n3oumjtrjUjhDEC2vIcXaeqCIdvRtQ6oxy4ZxGHxXxR7H04xXelrRd13Czb9KYsRi\nVfzCy/KhGabmJwUmFFZ8DsMXy21p6Vfe3aQuBK5jHpTLRMxg5rZqH9X1tbiHzu/n\noFsg7AKFYIB+EIbW1uMBXZ1YqHZEECG5pA+x7Jue3Ok3A8PAE/s1hh4p3iM1FiE1\nrKSS/WLgmWJMnWV8YeYmikmke+MrFao1SEa/3PS39WEOqBgk2hai+GatTDR/dyBZ\ncA0+r9oL+AuDyEWHJihHrgsCoc3tENKJr5HDqlpSIaocy1K68Fs27EJmEZuoD/Ku\nFwBjBhBRuJfIdkJ/nia73l76HA8+gFYuXByO01bLfbiRM+O9YIyQJ56K0fN2o0Jz\nhc2D9rNruN7NAAXKx4e+DJ+Rg+9qoPZLgYTkPKHHuplplToZ5ngG2cvVxH9k9kyl\nQB3gFl79huZghlREXqbB+eMG2/E2OtOjMNDY2SFZ2B97X264eo4WwCXszbYCI6Lk\n1wlU5P8m9DZnUBOtr0Nl3bECAwEAAQ==\n-----END PUBLIC KEY-----\n',1,'2026-09-11 04:29:09','2026-09-11 04:34:51'),
(4,'ronnieformento','ronnieformento@thelewiscollege.edu.ph','$2y$10$.ATokJH1FU4XwvyT9pg5NuiM9YbOPBJqSjwmRB53vUpygDUih4anC','Ronnie Formento','CCS','Dean','female',3,'manager',1,NULL,'-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxz5umOi5by4n+O5JMs6c\nJGrplEyH8EOGsXYueZVn74mVie+XGJ5tWTUv2gG42ce5M2liQVOZ4r5p+xXeJbeH\nzQy6B8qS9b+roj8wXDlDxQKy0GKkI/RIbzBthFESINUePoo4NSIk7pLwCAwEHvd/\nl8q1uE1F3JIq4FFgXnpI6emjMRMBr1a8ZVNdErFHITpVPUvkrlysQ4W4/v0SChHi\nh4li1I+wLU3ababldr4UvjuWKKa3sY2/6A+AAm5tSc3IxsApLZy0d6/g+E439bOq\nAelnP1lqiD7tMe4RkFrV4ujgiC35e5pWJwpqhNOgVtFWcBpirMIlbYIvj3jouZdJ\ng1skjSsY4c0SdorMHIx5mpi2ZTE+e5iQgI9OlGVKQa+pNafIN4AxbkLDL7KUviJP\nGNTlNi2jYMKYPkhT6Au2Y705F4Jld6e+csHEH5lyt9S9rU2bfJMyx3mRlpX7sRgd\ndPhARfpxXC5MxAY8454nWvD8/nR5d8kPKD0lwMMMdxYhYz+1s1JvsSa8uG9ocJug\nq+7jAAhmXaLWMOOysCd76WI8Fq+Wn0zxJz/Tme5VbYoGUgvnQYSujmNQuAD02/WP\nqukbyWDMJlzsSB7HDt/MwIKOE7KyJG1Ca4N8e7r9LdWHpxBcVFqFfJJN2PjsOaP1\nD/XFcmGLpuPpe1fDS4uTWtMCAwEAAQ==\n-----END PUBLIC KEY-----\n',1,'2026-09-11 04:35:58','2026-09-11 04:36:48'),
(5,'cyrilgardon','cyrilgardo@thelewiscollege.edu.ph','$2y$10$m9j3qPvbxnbjQTPDam1jnOrSU4pkqVotT.r5ZBgHWPLywwMfTZ.Fu','Cyril Gardon','CCS','Instructor','male',1,'employee',0,NULL,'-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAsXbMHCW445wnrobKtixB\nvtrgPVdo8ZU481One5JGIKWmCiYTLs426RkDdnOk0q1p1/Iz7zItsTRMCfRmmM+I\nx1TAh7R+hYUHriS3jwlV5GtN1Kd63sDAfqQih6M9mWpEWQv7iSNblnQT4LQG0R6F\nuZnhw+ICOjPEu8LzU3paollj68KN9pnrIlIntosf9HGBSKyvzYGFYafD0ouWuREA\nsOQuPcLMslpeBv8enZH1ewWUB4kM39qGyuShv+yzyFr5GBDwzKGD1WLHdnq8U1NM\nSTce4u2fycLeA6Hp+o6nPbOgStX7xLyLNoKCG7SE97vx3/nIoAn1WeUeMOVZ+Irr\nXg++USjz5SuwhrxMKGyMO99GbINUTyCUMhgKMb5MQhobX8spLGMAYHJCLXwqVwjL\nuSGW1EnECH/hxp0VuBK3ZfgJvaUUJvL/X+0WceO/LPwL1qwx6VR+CuVz+EZt8ZSh\nFJLfqTha3g58wa5XKi42ElunKzMUDgdq2VGoCnvszaVMryLItyqXo+gnP0ZUTA07\nOFdNiraP2jvAof683bRb5vfJXxZ7EyDQcaF90AfmlXHUGWraH+rqqUCc6iEmfVpd\nr+DY3TYncxdaoSxExHTAmkLrm6eyK4azAThuftOWf3i/PuzsY9/s9K+IgE3U4B7g\n/qD3rhVlv/UXNtU13WgyOBsCAwEAAQ==\n-----END PUBLIC KEY-----\n',0,'2026-09-11 04:37:38','2026-09-11 04:37:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn_challenges`
--

DROP TABLE IF EXISTS `webauthn_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `challenge` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` enum('registration','approval') COLLATE utf8mb4_unicode_ci NOT NULL,
  `context_type` enum('leave_request','device_change') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `context_id` int DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `webauthn_challenges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn_challenges`
--

LOCK TABLES `webauthn_challenges` WRITE;
/*!40000 ALTER TABLE `webauthn_challenges` DISABLE KEYS */;
INSERT INTO `webauthn_challenges` VALUES
(1,1,'paDFDkzsu6Fwc0WaKKqBmqoB8ihAZpebFh229NAfPFI','registration',NULL,NULL,'2026-09-11 03:12:37','2026-09-11 03:07:37');
/*!40000 ALTER TABLE `webauthn_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn_credentials`
--

DROP TABLE IF EXISTS `webauthn_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn_credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `credential_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attestation_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `trust_path` text COLLATE utf8mb4_unicode_ci,
  `aaguid` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transports` json DEFAULT NULL,
  `sign_count` bigint unsigned NOT NULL DEFAULT '0',
  `label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_fingerprint_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_id` (`credential_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `webauthn_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn_credentials`
--

LOCK TABLES `webauthn_credentials` WRITE;
/*!40000 ALTER TABLE `webauthn_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'railway'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-11  5:19:49
