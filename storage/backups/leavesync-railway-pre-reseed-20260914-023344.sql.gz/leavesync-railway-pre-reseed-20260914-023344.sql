/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` int DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_action` (`action`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` VALUES
(7,1,'login_success','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:06:32'),
(9,1,'login_success','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:07:22'),
(10,1,'webauthn_credential_registered','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:07:50'),
(11,1,'webauthn_credential_removed','user',1,NULL,'[]','216.247.84.154','c48d9944bc9cac726bb01e4c7116ada183b221f56d4bc143de0420a460562b81','2026-09-11 03:07:55'),
(12,1,'login_failed','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:28:14'),
(13,1,'login_failed','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:28:15'),
(14,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:28:21'),
(15,1,'create_user','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:29:09'),
(18,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:29:46'),
(22,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:32:50'),
(26,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:35:16'),
(27,1,'create_user','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:35:58'),
(29,1,'login_success','user',1,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-11 04:36:31'),
(31,1,'create_user','user',5,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:37:38'),
(32,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-11 04:38:09'),
(33,1,'login_success','user',1,NULL,'[]','138.84.134.51','e6e47f9e639167af5b2ee58d8cd6d961572ac0400411bd78bf24cd10d6ada5f3','2026-09-13 12:57:10'),
(34,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:18:58'),
(35,1,'create_user','user',2,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:19:37'),
(36,1,'create_user','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:20:20'),
(37,1,'create_user','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:21:08'),
(38,1,'update_user','user',4,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 00:21:42'),
(39,1,'update_user','user',4,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 00:21:45'),
(40,4,'login_success_google','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:49:06'),
(41,4,'password_set','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:49:26'),
(42,2,'login_success_google','user',2,NULL,'[]','203.177.49.42','a96d296d405dba857ed820c953249a063ef9444c11929b521f90895520d81ff7','2026-09-14 00:51:08'),
(43,2,'password_set','user',2,NULL,'[]','203.177.49.42','a96d296d405dba857ed820c953249a063ef9444c11929b521f90895520d81ff7','2026-09-14 00:51:24'),
(44,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:51:50'),
(45,4,'login_success','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:53:57'),
(46,3,'login_success_google','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:55:05'),
(47,3,'password_set','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:55:14'),
(48,4,'login_success','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:56:10'),
(49,4,'create_leave_request','leave_request',1,NULL,'{\"bypass_reason\": null, \"assigned_supervisor_id\": null, \"original_supervisor_id\": 3, \"bypassed_supervisor_ids\": []}','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:56:25'),
(50,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:56:53'),
(51,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:57:31'),
(52,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 00:59:22'),
(53,3,'login_success_google','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:05:02'),
(54,4,'login_success','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:05:16'),
(55,4,'create_leave_request','leave_request',2,NULL,'{\"bypass_reason\": null, \"assigned_supervisor_id\": null, \"original_supervisor_id\": 3, \"bypassed_supervisor_ids\": []}','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:05:36'),
(56,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:05:48'),
(57,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:06:04'),
(58,NULL,'update_user','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:25:15'),
(59,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:25:42'),
(60,4,'login_success','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:26:29'),
(61,2,'device_change_requested','user',2,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:26:51'),
(62,2,'login_failed_untrusted_device','user',2,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:26:51'),
(63,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:26:55'),
(64,1,'webauthn_credential_registered','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:27:16'),
(65,1,'device_request_approved','device_change_request',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:27:27'),
(66,2,'login_success','user',2,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:27:37'),
(67,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:30:34'),
(68,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:30:36'),
(69,4,'login_success','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:31:07'),
(70,3,'login_failed','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:33:30'),
(71,3,'login_failed','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:33:31'),
(72,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:33:33'),
(73,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:33:51'),
(74,2,'login_success','user',2,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:34:48'),
(75,4,'login_success','user',4,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:54:58'),
(76,3,'login_success','user',3,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:55:10'),
(77,2,'login_success','user',2,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:55:33'),
(78,1,'login_success','user',1,NULL,'[]','203.177.49.42','2ab34c54e3c1227c7332d41276d84613bb719392148c1f8f76b7047ab3f7e0eb','2026-09-14 01:55:46'),
(79,2,'login_success','user',2,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:12:00'),
(80,3,'login_success','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:12:17'),
(81,4,'login_success','user',4,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:12:34'),
(82,4,'create_leave_request','leave_request',3,NULL,'{\"bypass_reason\": null, \"assigned_supervisor_id\": 3, \"original_supervisor_id\": 3, \"bypassed_supervisor_ids\": []}','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:13:05'),
(83,3,'login_success','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:13:18'),
(84,2,'login_success','user',2,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:14:55'),
(85,3,'login_success','user',3,NULL,'[]','180.193.218.250','a69d8edbafee3fcbeb68a1f17ea10e89feead9bc1a53bda184702c4b772ffbdc','2026-09-14 02:15:22');
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_change_requests`
--

DROP TABLE IF EXISTS `device_change_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_change_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `fingerprint_hash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `requested_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resolved_by` (`resolved_by`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `device_change_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `device_change_requests_ibfk_2` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_change_requests`
--

LOCK TABLES `device_change_requests` WRITE;
/*!40000 ALTER TABLE `device_change_requests` DISABLE KEYS */;
INSERT INTO `device_change_requests` VALUES
(1,2,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"user_agent\":\"Mozilla\\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/153.0.0.0 Safari\\/537.36\",\"accept_language\":\"en-US,en;q=0.9\",\"accept_encoding\":\"gzip, deflate, br, zstd\",\"ip_address\":\"203.177.49.42\",\"browser\":\"Chrome 153\",\"os\":\"Windows 10\",\"device\":\"Windows PC\",\"screen_resolution\":\"1536x730\",\"timezone\":\"Asia\\/Manila\",\"language\":\"en-US\",\"platform\":\"Win32\",\"hardware_concurrency\":12,\"device_memory\":16}','203.177.49.42','Chrome 153','approved','2026-09-14 01:26:51','2026-09-14 01:27:27',1);
/*!40000 ALTER TABLE `device_change_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_fingerprints`
--

DROP TABLE IF EXISTS `device_fingerprints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_fingerprints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `fingerprint_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_info` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_info` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_trusted` tinyint(1) DEFAULT '0',
  `last_used` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_fingerprint` (`fingerprint_hash`),
  CONSTRAINT `device_fingerprints_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_fingerprints`
--

LOCK TABLES `device_fingerprints` WRITE;
/*!40000 ALTER TABLE `device_fingerprints` DISABLE KEYS */;
INSERT INTO `device_fingerprints` VALUES
(1,1,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"203.177.49.42\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','203.177.49.42','Chrome 153',1,'2026-09-14 01:55:46','2026-09-11 03:06:32','2026-09-14 01:55:46'),
(5,1,'c430cbd64980373a8a3183c8953c11de250fe5176919a928ccda32964a69b926','{\"os\": \"iOS 26.5.0\", \"device\": \"iPhone\", \"browser\": \"Safari 604\", \"language\": \"en-US\", \"platform\": \"iPhone\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"138.84.134.51\", \"user_agent\": \"Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1\", \"device_memory\": \"unknown\", \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"414x400\", \"hardware_concurrency\": 4}','138.84.134.51','Safari 604',1,'2026-09-13 12:57:10','2026-09-13 12:57:10','2026-09-13 12:57:10'),
(6,4,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"180.193.218.250\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','180.193.218.250','Chrome 153',1,'2026-09-14 02:12:34','2026-09-14 00:49:26','2026-09-14 02:12:34'),
(7,2,'af6db15b99d3949bf44bbd60009fbfc9fef0154c5771ea3b7b356e2f3864c113','{\"os\": \"Android 10\", \"device\": \"Android Device\", \"browser\": \"Chrome 152\", \"language\": \"en-US\", \"platform\": \"Linux armv81\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"203.177.49.42\", \"user_agent\": \"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Mobile Safari/537.36\", \"device_memory\": 4, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"411x842\", \"hardware_concurrency\": 8}','203.177.49.42','Chrome 152',1,'2026-09-14 00:51:24','2026-09-14 00:51:24','2026-09-14 00:51:24'),
(8,3,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"180.193.218.250\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','180.193.218.250','Chrome 153',1,'2026-09-14 02:15:22','2026-09-14 00:55:14','2026-09-14 02:15:22'),
(9,2,'18b2276f55c68967cf94b7ff96da1a5893215dd7b49ae176d6298d04f84122d4','{\"os\": \"Windows 10\", \"device\": \"Windows PC\", \"browser\": \"Chrome 153\", \"language\": \"en-US\", \"platform\": \"Win32\", \"timezone\": \"Asia/Manila\", \"ip_address\": \"180.193.218.250\", \"user_agent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36\", \"device_memory\": 16, \"accept_encoding\": \"gzip, deflate, br, zstd\", \"accept_language\": \"en-US,en;q=0.9\", \"screen_resolution\": \"1536x730\", \"hardware_concurrency\": 12}','180.193.218.250','Chrome 153',1,'2026-09-14 02:14:55','2026-09-14 01:27:27','2026-09-14 02:14:55');
/*!40000 ALTER TABLE `device_fingerprints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `digital_signatures`
--

DROP TABLE IF EXISTS `digital_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `digital_signatures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_id` int NOT NULL,
  `document_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signer_id` int NOT NULL,
  `signature_hash` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `certificate_data` longtext COLLATE utf8mb4_unicode_ci,
  `timestamp` timestamp NOT NULL,
  `is_valid` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_document_id` (`document_id`),
  KEY `idx_document_type` (`document_type`),
  KEY `idx_signer_id` (`signer_id`),
  CONSTRAINT `digital_signatures_ibfk_1` FOREIGN KEY (`signer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `digital_signatures`
--

LOCK TABLES `digital_signatures` WRITE;
/*!40000 ALTER TABLE `digital_signatures` DISABLE KEYS */;
/*!40000 ALTER TABLE `digital_signatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_balances`
--

DROP TABLE IF EXISTS `leave_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_balances` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leave_type_id` int NOT NULL,
  `total_days` decimal(6,2) DEFAULT NULL,
  `used_days` decimal(6,2) DEFAULT '0.00',
  `pending_days` decimal(6,2) DEFAULT '0.00',
  `balance` decimal(6,2) DEFAULT NULL,
  `fiscal_year` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_leave_type` (`user_id`,`leave_type_id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_fiscal_year` (`fiscal_year`),
  CONSTRAINT `leave_balances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leave_balances_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_balances`
--

LOCK TABLES `leave_balances` WRITE;
/*!40000 ALTER TABLE `leave_balances` DISABLE KEYS */;
INSERT INTO `leave_balances` VALUES
(25,2,1,7.00,0.00,0.00,7.00,2026,'2026-09-14 00:19:37','2026-09-14 00:19:37'),
(26,2,2,5.00,0.00,0.00,5.00,2026,'2026-09-14 00:19:37','2026-09-14 00:19:37'),
(27,2,3,999.00,0.00,0.00,999.00,2026,'2026-09-14 00:19:37','2026-09-14 00:19:37'),
(28,2,4,105.00,0.00,0.00,105.00,2026,'2026-09-14 00:19:37','2026-09-14 00:19:37'),
(29,2,5,7.00,0.00,0.00,7.00,2026,'2026-09-14 00:19:37','2026-09-14 00:19:37'),
(30,2,6,3.00,0.00,0.00,3.00,2026,'2026-09-14 00:19:37','2026-09-14 00:19:37'),
(31,3,1,7.00,0.00,0.00,7.00,2026,'2026-09-14 00:20:20','2026-09-14 00:20:20'),
(32,3,2,5.00,0.00,0.00,5.00,2026,'2026-09-14 00:20:20','2026-09-14 00:20:20'),
(33,3,3,999.00,0.00,0.00,999.00,2026,'2026-09-14 00:20:20','2026-09-14 00:20:20'),
(34,3,4,105.00,0.00,0.00,105.00,2026,'2026-09-14 00:20:20','2026-09-14 00:20:20'),
(35,3,5,7.00,0.00,0.00,7.00,2026,'2026-09-14 00:20:20','2026-09-14 00:20:20'),
(36,3,6,3.00,0.00,0.00,3.00,2026,'2026-09-14 00:20:20','2026-09-14 00:20:20'),
(37,4,1,7.00,0.00,2.00,5.00,2026,'2026-09-14 00:21:08','2026-09-14 01:05:36'),
(38,4,2,5.00,0.00,1.00,4.00,2026,'2026-09-14 00:21:08','2026-09-14 02:13:05'),
(39,4,3,999.00,0.00,0.00,999.00,2026,'2026-09-14 00:21:08','2026-09-14 00:21:08'),
(40,4,4,105.00,0.00,0.00,105.00,2026,'2026-09-14 00:21:08','2026-09-14 00:21:08'),
(41,4,5,7.00,0.00,0.00,7.00,2026,'2026-09-14 00:21:08','2026-09-14 00:21:08'),
(42,4,6,3.00,0.00,0.00,3.00,2026,'2026-09-14 00:21:08','2026-09-14 00:21:08');
/*!40000 ALTER TABLE `leave_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_requests`
--

DROP TABLE IF EXISTS `leave_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leave_type_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `number_of_days` decimal(6,2) DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','approved','rejected','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `supervisor_status` enum('pending','approved','rejected','not_required') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `hr_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `manager_id` int DEFAULT NULL,
  `assigned_supervisor_id` int DEFAULT NULL,
  `manager_comments` text COLLATE utf8mb4_unicode_ci,
  `hr_id` int DEFAULT NULL,
  `hr_comments` text COLLATE utf8mb4_unicode_ci,
  `digital_signature` text COLLATE utf8mb4_unicode_ci,
  `signature_timestamp` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `leave_type_id` (`leave_type_id`),
  KEY `hr_id` (`hr_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_manager_id` (`manager_id`),
  KEY `idx_start_date` (`start_date`),
  KEY `idx_end_date` (`end_date`),
  KEY `idx_assigned_supervisor_id` (`assigned_supervisor_id`),
  CONSTRAINT `leave_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leave_requests_ibfk_2` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`),
  CONSTRAINT `leave_requests_ibfk_3` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leave_requests_ibfk_4` FOREIGN KEY (`hr_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leave_requests_ibfk_5` FOREIGN KEY (`assigned_supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_requests`
--

LOCK TABLES `leave_requests` WRITE;
/*!40000 ALTER TABLE `leave_requests` DISABLE KEYS */;
INSERT INTO `leave_requests` VALUES
(1,4,1,'2026-09-17','2026-09-17',1.00,'test','pending','not_required','pending',3,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-14 00:56:25','2026-09-14 00:56:25'),
(2,4,1,'2026-09-21','2026-09-21',1.00,'testing','pending','not_required','pending',3,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-14 01:05:36','2026-09-14 01:05:36'),
(3,4,2,'2026-09-14','2026-09-14',1.00,'test','pending','pending','pending',3,3,NULL,NULL,NULL,NULL,NULL,'2026-09-14 02:13:05','2026-09-14 02:13:05');
/*!40000 ALTER TABLE `leave_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leave_types`
--

DROP TABLE IF EXISTS `leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leave_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `days_per_year` int NOT NULL,
  `is_paid` tinyint(1) DEFAULT '1',
  `requires_documentation` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leave_types`
--

LOCK TABLES `leave_types` WRITE;
/*!40000 ALTER TABLE `leave_types` DISABLE KEYS */;
INSERT INTO `leave_types` VALUES
(1,'Vacation Leave','Paid vacation leave; must be filed at least 3 days before the requested start date',7,1,0,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(2,'Sick Leave','Leave for medical reasons',5,1,0,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(3,'Leave Without Pay','Unpaid leave, only usable once Vacation and Sick leave balances are exhausted',999,0,1,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(4,'Maternity Leave','Leave for maternity (RA 11210); female employees only',105,1,1,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(5,'Paternity Leave','Leave for paternity (RA 8187); male employees only',7,1,1,'2026-09-11 02:57:21','2026-09-11 02:57:21'),
(6,'Bereavement Leave','Leave for the death of an immediate family member',3,1,1,'2026-09-11 02:57:21','2026-09-11 02:57:21');
/*!40000 ALTER TABLE `leave_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mfa_secrets`
--

DROP TABLE IF EXISTS `mfa_secrets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mfa_secrets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_codes` json DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `mfa_secrets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mfa_secrets`
--

LOCK TABLES `mfa_secrets` WRITE;
/*!40000 ALTER TABLE `mfa_secrets` DISABLE KEYS */;
/*!40000 ALTER TABLE `mfa_secrets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `notification_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_entity_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_entity_id` int DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(3,4,'Account activated','Your password was set and this device was registered as a trusted device.','success','user',4,0,'2026-09-14 00:49:26',NULL),
(4,2,'Account activated','Your password was set and this device was registered as a trusted device.','success','user',2,0,'2026-09-14 00:51:24',NULL),
(5,3,'Account activated','Your password was set and this device was registered as a trusted device.','success','user',3,0,'2026-09-14 00:55:14',NULL),
(6,2,'New Leave Request','New leave request from Ronnie Formento','info','leave_request',1,0,'2026-09-14 00:56:25',NULL),
(7,2,'New Leave Request','New leave request from Ronnie Formento','info','leave_request',2,0,'2026-09-14 01:05:36',NULL),
(8,3,'New Leave Request','New leave request from Ronnie Formento','info','leave_request',3,0,'2026-09-14 02:13:05',NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `device_id` (`device_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_token_hash` (`token_hash`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`device_id`) REFERENCES `device_fingerprints` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
(17,1,'c263feee66cbacff7eac5293e3c5fbfa9b434a295864217e0270709321f87cfe',1,'203.177.49.42','2026-10-11 04:46:22','2026-09-11 04:38:09'),
(37,3,'98a689f221d3ddd71df6fb3ef9d47eefe94f8a4e55ed9f482aac5e0887169730',8,'203.177.49.42','2026-10-14 01:30:34','2026-09-14 01:30:34'),
(52,3,'75c9c5505f929f504c3f33e809484a69764967004c4aadf77f75db51ab61dd9a',8,'180.193.218.250','2026-10-14 02:33:16','2026-09-14 02:15:22');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_id_sequence`
--

DROP TABLE IF EXISTS `user_id_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_id_sequence` (
  `id` tinyint NOT NULL,
  `next_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_id_sequence`
--

LOCK TABLES `user_id_sequence` WRITE;
/*!40000 ALTER TABLE `user_id_sequence` DISABLE KEYS */;
INSERT INTO `user_id_sequence` VALUES
(1,5);
/*!40000 ALTER TABLE `user_id_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_id` int DEFAULT NULL,
  `role` enum('employee','manager','hr','admin') COLLATE utf8mb4_unicode_ci DEFAULT 'employee',
  `is_active` tinyint(1) DEFAULT '1',
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `public_key` longtext COLLATE utf8mb4_unicode_ci,
  `password_set` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_role` (`role`),
  KEY `idx_supervisor_id` (`supervisor_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'admin','admin@thelewiscollege.edu.ph','$2y$10$VYHGcBlY1AY9YAnbwcxG9uj5fjLUT9WwOks2TuBj/hxOtS/APudJy','System Administrator','ADMIN',NULL,'male',NULL,'admin',1,NULL,NULL,1,'2026-08-26 03:32:46','2026-08-27 00:45:08'),
(2,'josefjurendelcastro','josefjurendelcastro@thelewiscollege.edu.ph','$2y$10$y7JudMH8ai4UcWzOhwrG2eKEu5t0m9kciIZXmjfU0aHn154wlclVW','Josef Jurendel Castro','ADMIN','HR Officer','male',1,'hr',1,NULL,'-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAxIyjAXAtxIWRIWnn02hm\nmr7Qsd5+5LvH/nWVInbj+x2EUbKDnBAiIzKVxJbUl9CsxkrU9MPKgks2pdULf9ks\nz8yNo53+K91T0TkfWaAwJdZFQNQCrn4bNLU4loYIjOt6CviuyXFVGeJBbsKnWbwK\n6qc98rzyfM43gZ1vgYBtVf7jE/LyafUrgfxHLDV/yvZlzki7XDwlWxgQ8OneUpbn\n1m4KRGOg5ZBXb88RRfsmCKExuFIWVZ8iO53M5LL4k0KXBXDvzuzHcdJodPZJ6/VJ\nd1lDeO91OcXfskh1e8QGeALu7wBLNfi+NPjph23kj9lLRdDwMI/7IELAycCk+0EA\nhiYs4U4Sh0r+E6y7vddpBjeJFVq4hzakm68ioavxB+HLYZQ4anPtjHcD4tqTwg4B\nmIIo6a6vz5YxQH2+jq1FMd1u4wnCwwBDRVzgOgH0YWfXhRbWXX/s3EyRqETNkU2/\nd83YKnepvg++6jkYdSNNbdM4PFIu5XLUnTJgETHlhUYENB7hX1etEVt7pUfs3gM2\n1cUo2pLGkLwwEN8GsfpJ6EGOh9jOoa4qfZcLh0rm837imzn3Rf/7ntZz/h07Veyi\njphJB5q3zENUwU+Kus7XXO0x4oRWERG7Zf24A2ly+pLhUNh7akvDMVwhO5ouHJUb\ne1eVt9db5BeS28faEhXq+DECAwEAAQ==\n-----END PUBLIC KEY-----\n',1,'2026-09-14 00:19:37','2026-09-14 00:51:24'),
(3,'cyrilchristiangardon','cyrilchristiangardon@thelewiscollege.edu.ph','$2y$10$mYa0noa0NWHTUnvtAMWgS.EH0ccTA3m0iIeAPTwd8RToI46ke.Be2','Cyril Christian Gardon','CBE','Dean','female',2,'manager',1,NULL,'-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAkrEpjgM69Nszv2znclJe\nxkGvvEdYhqKJHWXjgQyOk0xB6yPIurC4VIeVSROcUHM7OHJtWD6TQwYY+CALW4KW\nnsJ2ChJt7zpJ4VnFJNR5UHvQ36Bozr0ewO6sVveYGyRsXAiuRHAkZEwfH+X41rei\n4+L131sWUVjlJeqDhQv5VOH1CGRgfLc6LVSQ+LbFoenls5R0mnOlTT8puSZH9lZg\nNfwS1NWSZoi0MnE+1qo+2execnoo84TTHvdtVk64OtXolG7dlzDeAITV1Y/ZiC+A\ncVhPYTlxO1DeqpjOeoukwubrebwuytLIaJ2qrtbKMBXogpXRwFLXie+w5t2ALQbE\n++y2/BEcoW/IZaDqEVYrN1wLFbmeidGL29RayKGx10ljZ+gjuycyfwEyWSHUo7EH\nI1pZt8tGhX1U1ZZcwXniry6uZg4bDxM0uawcmCOhIlfJSlV/u3TK+UgxAlQaKiN1\nzn+NBBvvXjO5dTBvouqtFCSwuBscmUPDIbvDq2UWeNm1RaaV4xG519gUDXFXAj6p\noBucGMJn5NSKA75uTOVrXATuUEojbYJJZuTbl+u8EbmNXaKaGV1Nz8Gbez2xC7Ii\nmYtpQNRwhmwxb3c4JKnfLdem/RQHFB6l9BSeLblThnk0vx4bO9/frGZzM9vq/hTq\n8q/5qjdvgKcOA2BroGkoM68CAwEAAQ==\n-----END PUBLIC KEY-----\n',1,'2026-09-14 00:20:20','2026-09-14 00:55:14'),
(4,'ronnieformento','ronnieformento@thelewiscollege.edu.ph','$2y$10$RSlanMRzdAzdyN5cge9wEufriEtFbLeV8KzBRAjh16O.WlAulJnZG','Ronnie Formento','CBE','Instructor','male',3,'employee',1,NULL,'-----BEGIN PUBLIC KEY-----\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA3KKNYPbfrtwtnnu2/G7C\nglZTznIxIjKpOz5mcA7Emlvhg0bz7FVz+sx7/H9FQ09jPaDKxSmiG8cD8nZdAj6s\nD89aU73PGT3uXLmd1ZrX7wospLVKbIlz3fSsDH9kjNJIoMvSaxzIxfl/Qhept3lh\nejStqm7t90ZqT74WEDVxDnmQz99qhfRKGPlTl0DqmOVa4xoRQ0ca3h6Eb0V1gGPi\n2N+bYIvgtAXyo07j+pg/qSzyTPeqwAfKoeK6W0gSplRO8YYbJTDShZkajJEBtwC1\nSn3TGs7MaldBPvIuyAUThGtvtH3A8/4g8crPtieW81HJGRQj0o88F8IFpqFzB/Gb\nSo52Yr0Jbh37X+hveHXVHoyjLNIDWeFSsMU7Urw9MtDSYtjq6B3s9vOb1OG2CSCQ\n/DT1vzxBx1yhKmGL8HIBmnJlggaOgXEgQolHLoRCYzE8uIgg4tgbDcuUOgz17sb4\n/WbSSlxT7cniaaex3dp174a+jeRY5KerrqwhA+yKZjOCnRFM7MVnBF/2Xc8g8Vcj\naV1A1oIMqez2Q+Gdrrpts5o1zBAUF+DXb/xBsaJ85+XczeUYgq/zx8xShcfgJzcZ\n3ruqDBJ2Rs2jTAWc3YCe0MQHdzvtzZjBrxHjRUFcFL4ixluBed6mapRKCeNdDe2D\nh73DTm6FMas6fzRlH/AOWHUCAwEAAQ==\n-----END PUBLIC KEY-----\n',1,'2026-09-14 00:21:08','2026-09-14 01:25:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn_challenges`
--

DROP TABLE IF EXISTS `webauthn_challenges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn_challenges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `challenge` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` enum('registration','approval') COLLATE utf8mb4_unicode_ci NOT NULL,
  `context_type` enum('leave_request','device_change') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `context_id` int DEFAULT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `webauthn_challenges_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn_challenges`
--

LOCK TABLES `webauthn_challenges` WRITE;
/*!40000 ALTER TABLE `webauthn_challenges` DISABLE KEYS */;
INSERT INTO `webauthn_challenges` VALUES
(1,1,'paDFDkzsu6Fwc0WaKKqBmqoB8ihAZpebFh229NAfPFI','registration',NULL,NULL,'2026-09-11 03:12:37','2026-09-11 03:07:37');
/*!40000 ALTER TABLE `webauthn_challenges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn_credentials`
--

DROP TABLE IF EXISTS `webauthn_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn_credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `credential_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attestation_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `trust_path` text COLLATE utf8mb4_unicode_ci,
  `aaguid` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transports` json DEFAULT NULL,
  `sign_count` bigint unsigned NOT NULL DEFAULT '0',
  `label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_fingerprint_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_label` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_used_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credential_id` (`credential_id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `webauthn_credentials_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn_credentials`
--

LOCK TABLES `webauthn_credentials` WRITE;
/*!40000 ALTER TABLE `webauthn_credentials` DISABLE KEYS */;
INSERT INTO `webauthn_credentials` VALUES
(2,1,'DFbUKlYzGV3FCMIqUHJkJw','pQECAyYgASFYIOCpzVbRmVthVRyYO9HK9bMirllhGXlMW6ia/HcdXYCCIlggNSk42qHREovNBJCRseckpfnwyBNj+frQJhujFx/YjnU=','none',NULL,'ea9b8d66-4d01-1d21-3ce4-b6b48cb575d4','[]',0,'Passkey','ae0b268077de8046ff0c36bc810656983c652257c17979a8f903b722d0aae064','Chrome • Windows PC','2026-09-14 01:27:16','2026-09-14 01:27:27');
/*!40000 ALTER TABLE `webauthn_credentials` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-14  2:34:22
